marks = 30
if marks < 50:
	print("Fail")
elif marks < 80:
	print("Pass")
else:
	print("Excellent")