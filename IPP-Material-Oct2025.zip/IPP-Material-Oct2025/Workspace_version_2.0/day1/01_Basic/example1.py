variable_A = 200
variable_B = "Hello"

print (type(variable_A))
print (type(variable_B))
