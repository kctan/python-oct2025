#"Hello world" will be printed 5 times

i = 0
while i < FIX_ME:
    FIX_ME
    
    i = i + FIX_ME