import os

# error if file do not exist
if os.path.exists("hello2.txt"):
    os.unlink("hello2.txt")

# get current working directory
#print(os.getcwd())

# delete directory (can only delete empty folder)
#os.rmdir("folder2")

import shutil
# delete directory (with content)
# error if folder is not found
shutil.rmtree("a")


